--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bulingo;
--
-- Name: bulingo; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bulingo WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.utf8' LC_CTYPE = 'en_US.utf8';


ALTER DATABASE bulingo OWNER TO postgres;

\connect bulingo

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: AnnotationResources; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AnnotationResources" (
    target_annotation_id integer,
    body_annotation_id integer,
    _id integer NOT NULL,
    id character varying(255),
    value text,
    source character varying(255),
    type character varying(255),
    format character varying(255),
    language character varying(255),
    "processingLanguage" character varying(255),
    "textDirection" character varying(255),
    creator character varying(255),
    purpose character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."AnnotationResources" OWNER TO postgres;

--
-- Name: AnnotationResources__id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AnnotationResources__id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AnnotationResources__id_seq" OWNER TO postgres;

--
-- Name: AnnotationResources__id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AnnotationResources__id_seq" OWNED BY public."AnnotationResources"._id;


--
-- Name: AnnotationSelectors; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AnnotationSelectors" (
    id integer NOT NULL,
    resource_id integer,
    type character varying(255),
    value character varying(255),
    "conformsTo" character varying(255),
    exact character varying(255),
    prefix character varying(255),
    suffix character varying(255),
    start character varying(255),
    "end" character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."AnnotationSelectors" OWNER TO postgres;

--
-- Name: AnnotationSelectors_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."AnnotationSelectors_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AnnotationSelectors_id_seq" OWNER TO postgres;

--
-- Name: AnnotationSelectors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."AnnotationSelectors_id_seq" OWNED BY public."AnnotationSelectors".id;


--
-- Name: Annotations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Annotations" (
    "@context" character varying(255) NOT NULL,
    id integer NOT NULL,
    type character varying(255) NOT NULL,
    creator character varying(255),
    motivation character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Annotations" OWNER TO postgres;

--
-- Name: Annotations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Annotations_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Annotations_id_seq" OWNER TO postgres;

--
-- Name: Annotations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Annotations_id_seq" OWNED BY public."Annotations".id;


--
-- Name: Auths; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Auths" (
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Auths" OWNER TO postgres;

--
-- Name: Comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Comments" (
    id integer NOT NULL,
    comment_to character varying(255) NOT NULL,
    rating double precision NOT NULL,
    text character varying(255) NOT NULL,
    comment_by character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Comments" OWNER TO postgres;

--
-- Name: Comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Comments_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Comments_id_seq" OWNER TO postgres;

--
-- Name: Comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Comments_id_seq" OWNED BY public."Comments".id;


--
-- Name: ExamChoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExamChoices" (
    id integer NOT NULL,
    question_id integer NOT NULL,
    "desc" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ExamChoices" OWNER TO postgres;

--
-- Name: ExamChoices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExamChoices_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ExamChoices_id_seq" OWNER TO postgres;

--
-- Name: ExamChoices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExamChoices_id_seq" OWNED BY public."ExamChoices".id;


--
-- Name: ExamQuestions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExamQuestions" (
    id integer NOT NULL,
    lang_abbr character varying(255),
    "desc" character varying(255),
    answer_id integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ExamQuestions" OWNER TO postgres;

--
-- Name: ExamQuestions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExamQuestions_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ExamQuestions_id_seq" OWNER TO postgres;

--
-- Name: ExamQuestions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExamQuestions_id_seq" OWNED BY public."ExamQuestions".id;


--
-- Name: ExerciseChoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExerciseChoices" (
    choice_id integer NOT NULL,
    question_id integer NOT NULL,
    "desc" character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ExerciseChoices" OWNER TO postgres;

--
-- Name: ExerciseChoices_choice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExerciseChoices_choice_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ExerciseChoices_choice_id_seq" OWNER TO postgres;

--
-- Name: ExerciseChoices_choice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExerciseChoices_choice_id_seq" OWNED BY public."ExerciseChoices".choice_id;


--
-- Name: ExerciseProgresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExerciseProgresses" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    exercise_id integer NOT NULL,
    question_done integer NOT NULL,
    questions integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ExerciseProgresses" OWNER TO postgres;

--
-- Name: ExerciseProgresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExerciseProgresses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ExerciseProgresses_id_seq" OWNER TO postgres;

--
-- Name: ExerciseProgresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExerciseProgresses_id_seq" OWNED BY public."ExerciseProgresses".id;


--
-- Name: ExerciseQuestions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExerciseQuestions" (
    question_id integer NOT NULL,
    lang_abbr character varying(255),
    exercise_id integer,
    answer_id integer,
    "desc" text,
    media_url character varying(255),
    media_type character varying(255),
    media_start_time integer,
    media_end_time integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."ExerciseQuestions" OWNER TO postgres;

--
-- Name: ExerciseQuestions_question_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."ExerciseQuestions_question_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."ExerciseQuestions_question_id_seq" OWNER TO postgres;

--
-- Name: ExerciseQuestions_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."ExerciseQuestions_question_id_seq" OWNED BY public."ExerciseQuestions".question_id;


--
-- Name: Exercises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Exercises" (
    exercise_id integer NOT NULL,
    title character varying(255),
    lang_abbr character varying(255),
    exercise_type character varying(255),
    level character varying(255),
    tags text,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Exercises" OWNER TO postgres;

--
-- Name: Exercises_exercise_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Exercises_exercise_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Exercises_exercise_id_seq" OWNER TO postgres;

--
-- Name: Exercises_exercise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Exercises_exercise_id_seq" OWNED BY public."Exercises".exercise_id;


--
-- Name: LanguageProgresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."LanguageProgresses" (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    lang_abbr character varying(255) NOT NULL,
    exercise_done integer[] NOT NULL,
    exercises integer NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."LanguageProgresses" OWNER TO postgres;

--
-- Name: LanguageProgresses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."LanguageProgresses_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."LanguageProgresses_id_seq" OWNER TO postgres;

--
-- Name: LanguageProgresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."LanguageProgresses_id_seq" OWNED BY public."LanguageProgresses".id;


--
-- Name: Languages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Languages" (
    abbr character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Languages" OWNER TO postgres;

--
-- Name: Levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Levels" (
    belongs_to character varying(255) NOT NULL,
    lang_abbr character varying(255) NOT NULL,
    grade character varying(255) NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Levels" OWNER TO postgres;

--
-- Name: Messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Messages" (
    id integer NOT NULL,
    to_username character varying(255) NOT NULL,
    from_username character varying(255) NOT NULL,
    message character varying(255) NOT NULL,
    new boolean DEFAULT true NOT NULL,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Messages" OWNER TO postgres;

--
-- Name: Messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Messages_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Messages_id_seq" OWNER TO postgres;

--
-- Name: Messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Messages_id_seq" OWNED BY public."Messages".id;


--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    username character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    bio character varying(255),
    avatar character varying(255),
    rating double precision,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Name: Writings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Writings" (
    writing_id integer NOT NULL,
    title character varying(255),
    text text,
    image text,
    written_by character varying(255) NOT NULL,
    assignee character varying(255),
    lang_abbr character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Writings" OWNER TO postgres;

--
-- Name: Writings_writing_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Writings_writing_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Writings_writing_id_seq" OWNER TO postgres;

--
-- Name: Writings_writing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Writings_writing_id_seq" OWNED BY public."Writings".writing_id;


--
-- Name: AnnotationResources _id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationResources" ALTER COLUMN _id SET DEFAULT nextval('public."AnnotationResources__id_seq"'::regclass);


--
-- Name: AnnotationSelectors id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationSelectors" ALTER COLUMN id SET DEFAULT nextval('public."AnnotationSelectors_id_seq"'::regclass);


--
-- Name: Annotations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Annotations" ALTER COLUMN id SET DEFAULT nextval('public."Annotations_id_seq"'::regclass);


--
-- Name: Comments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments" ALTER COLUMN id SET DEFAULT nextval('public."Comments_id_seq"'::regclass);


--
-- Name: ExamChoices id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamChoices" ALTER COLUMN id SET DEFAULT nextval('public."ExamChoices_id_seq"'::regclass);


--
-- Name: ExamQuestions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamQuestions" ALTER COLUMN id SET DEFAULT nextval('public."ExamQuestions_id_seq"'::regclass);


--
-- Name: ExerciseChoices choice_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseChoices" ALTER COLUMN choice_id SET DEFAULT nextval('public."ExerciseChoices_choice_id_seq"'::regclass);


--
-- Name: ExerciseProgresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseProgresses" ALTER COLUMN id SET DEFAULT nextval('public."ExerciseProgresses_id_seq"'::regclass);


--
-- Name: ExerciseQuestions question_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseQuestions" ALTER COLUMN question_id SET DEFAULT nextval('public."ExerciseQuestions_question_id_seq"'::regclass);


--
-- Name: Exercises exercise_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Exercises" ALTER COLUMN exercise_id SET DEFAULT nextval('public."Exercises_exercise_id_seq"'::regclass);


--
-- Name: LanguageProgresses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LanguageProgresses" ALTER COLUMN id SET DEFAULT nextval('public."LanguageProgresses_id_seq"'::regclass);


--
-- Name: Messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages" ALTER COLUMN id SET DEFAULT nextval('public."Messages_id_seq"'::regclass);


--
-- Name: Writings writing_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Writings" ALTER COLUMN writing_id SET DEFAULT nextval('public."Writings_writing_id_seq"'::regclass);


--
-- Data for Name: AnnotationResources; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AnnotationResources" (target_annotation_id, body_annotation_id, _id, id, value, source, type, format, language, "processingLanguage", "textDirection", creator, purpose, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."AnnotationResources" (target_annotation_id, body_annotation_id, _id, id, value, source, type, format, language, "processingLanguage", "textDirection", creator, purpose, "createdAt", "updatedAt") FROM '$$PATH$$/3041.dat';

--
-- Data for Name: AnnotationSelectors; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AnnotationSelectors" (id, resource_id, type, value, "conformsTo", exact, prefix, suffix, start, "end", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."AnnotationSelectors" (id, resource_id, type, value, "conformsTo", exact, prefix, suffix, start, "end", "createdAt", "updatedAt") FROM '$$PATH$$/3043.dat';

--
-- Data for Name: Annotations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Annotations" ("@context", id, type, creator, motivation, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Annotations" ("@context", id, type, creator, motivation, "createdAt", "updatedAt") FROM '$$PATH$$/3039.dat';

--
-- Data for Name: Auths; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Auths" (username, email, password, role, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Auths" (username, email, password, role, "createdAt", "updatedAt") FROM '$$PATH$$/3044.dat';

--
-- Data for Name: Comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Comments" (id, comment_to, rating, text, comment_by, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Comments" (id, comment_to, rating, text, comment_by, "createdAt", "updatedAt") FROM '$$PATH$$/3046.dat';

--
-- Data for Name: ExamChoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExamChoices" (id, question_id, "desc", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ExamChoices" (id, question_id, "desc", "createdAt", "updatedAt") FROM '$$PATH$$/3048.dat';

--
-- Data for Name: ExamQuestions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExamQuestions" (id, lang_abbr, "desc", answer_id, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ExamQuestions" (id, lang_abbr, "desc", answer_id, "createdAt", "updatedAt") FROM '$$PATH$$/3051.dat';

--
-- Data for Name: ExerciseChoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExerciseChoices" (choice_id, question_id, "desc", "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ExerciseChoices" (choice_id, question_id, "desc", "createdAt", "updatedAt") FROM '$$PATH$$/3055.dat';

--
-- Data for Name: ExerciseProgresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExerciseProgresses" (id, username, exercise_id, question_done, questions, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ExerciseProgresses" (id, username, exercise_id, question_done, questions, "createdAt", "updatedAt") FROM '$$PATH$$/3057.dat';

--
-- Data for Name: ExerciseQuestions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExerciseQuestions" (question_id, lang_abbr, exercise_id, answer_id, "desc", media_url, media_type, media_start_time, media_end_time, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."ExerciseQuestions" (question_id, lang_abbr, exercise_id, answer_id, "desc", media_url, media_type, media_start_time, media_end_time, "createdAt", "updatedAt") FROM '$$PATH$$/3059.dat';

--
-- Data for Name: Exercises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Exercises" (exercise_id, title, lang_abbr, exercise_type, level, tags, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Exercises" (exercise_id, title, lang_abbr, exercise_type, level, tags, "createdAt", "updatedAt") FROM '$$PATH$$/3053.dat';

--
-- Data for Name: LanguageProgresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."LanguageProgresses" (id, username, lang_abbr, exercise_done, exercises, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."LanguageProgresses" (id, username, lang_abbr, exercise_done, exercises, "createdAt", "updatedAt") FROM '$$PATH$$/3061.dat';

--
-- Data for Name: Languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Languages" (abbr, name, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Languages" (abbr, name, "createdAt", "updatedAt") FROM '$$PATH$$/3049.dat';

--
-- Data for Name: Levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Levels" (belongs_to, lang_abbr, grade, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Levels" (belongs_to, lang_abbr, grade, "createdAt", "updatedAt") FROM '$$PATH$$/3062.dat';

--
-- Data for Name: Messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Messages" (id, to_username, from_username, message, new, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Messages" (id, to_username, from_username, message, new, "createdAt", "updatedAt") FROM '$$PATH$$/3064.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (username, email, bio, avatar, rating, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Users" (username, email, bio, avatar, rating, "createdAt", "updatedAt") FROM '$$PATH$$/3065.dat';

--
-- Data for Name: Writings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Writings" (writing_id, title, text, image, written_by, assignee, lang_abbr, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Writings" (writing_id, title, text, image, written_by, assignee, lang_abbr, "createdAt", "updatedAt") FROM '$$PATH$$/3067.dat';

--
-- Name: AnnotationResources__id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AnnotationResources__id_seq"', 1, false);


--
-- Name: AnnotationSelectors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."AnnotationSelectors_id_seq"', 1, false);


--
-- Name: Annotations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Annotations_id_seq"', 1, false);


--
-- Name: Comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Comments_id_seq"', 5, true);


--
-- Name: ExamChoices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExamChoices_id_seq"', 1, false);


--
-- Name: ExamQuestions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExamQuestions_id_seq"', 1, false);


--
-- Name: ExerciseChoices_choice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExerciseChoices_choice_id_seq"', 60, true);


--
-- Name: ExerciseProgresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExerciseProgresses_id_seq"', 4, true);


--
-- Name: ExerciseQuestions_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."ExerciseQuestions_question_id_seq"', 16, true);


--
-- Name: Exercises_exercise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Exercises_exercise_id_seq"', 4, true);


--
-- Name: LanguageProgresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."LanguageProgresses_id_seq"', 4, true);


--
-- Name: Messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Messages_id_seq"', 8, true);


--
-- Name: Writings_writing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Writings_writing_id_seq"', 1, true);


--
-- Name: AnnotationResources AnnotationResources_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationResources"
    ADD CONSTRAINT "AnnotationResources_pkey" PRIMARY KEY (_id);


--
-- Name: AnnotationSelectors AnnotationSelectors_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationSelectors"
    ADD CONSTRAINT "AnnotationSelectors_pkey" PRIMARY KEY (id);


--
-- Name: Annotations Annotations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Annotations"
    ADD CONSTRAINT "Annotations_pkey" PRIMARY KEY (id);


--
-- Name: Auths Auths_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Auths"
    ADD CONSTRAINT "Auths_pkey" PRIMARY KEY (username);


--
-- Name: Comments Comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Comments"
    ADD CONSTRAINT "Comments_pkey" PRIMARY KEY (id);


--
-- Name: ExamChoices ExamChoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamChoices"
    ADD CONSTRAINT "ExamChoices_pkey" PRIMARY KEY (id);


--
-- Name: ExamQuestions ExamQuestions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamQuestions"
    ADD CONSTRAINT "ExamQuestions_pkey" PRIMARY KEY (id);


--
-- Name: ExerciseChoices ExerciseChoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseChoices"
    ADD CONSTRAINT "ExerciseChoices_pkey" PRIMARY KEY (choice_id);


--
-- Name: ExerciseProgresses ExerciseProgresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseProgresses"
    ADD CONSTRAINT "ExerciseProgresses_pkey" PRIMARY KEY (id);


--
-- Name: ExerciseQuestions ExerciseQuestions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExerciseQuestions"
    ADD CONSTRAINT "ExerciseQuestions_pkey" PRIMARY KEY (question_id);


--
-- Name: Exercises Exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Exercises"
    ADD CONSTRAINT "Exercises_pkey" PRIMARY KEY (exercise_id);


--
-- Name: LanguageProgresses LanguageProgresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."LanguageProgresses"
    ADD CONSTRAINT "LanguageProgresses_pkey" PRIMARY KEY (id);


--
-- Name: Languages Languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Languages"
    ADD CONSTRAINT "Languages_pkey" PRIMARY KEY (abbr);


--
-- Name: Levels Levels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Levels"
    ADD CONSTRAINT "Levels_pkey" PRIMARY KEY (belongs_to, lang_abbr, grade);


--
-- Name: Messages Messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Messages"
    ADD CONSTRAINT "Messages_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (username);


--
-- Name: Writings Writings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Writings"
    ADD CONSTRAINT "Writings_pkey" PRIMARY KEY (writing_id);


--
-- Name: AnnotationResources AnnotationResources_body_annotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationResources"
    ADD CONSTRAINT "AnnotationResources_body_annotation_id_fkey" FOREIGN KEY (body_annotation_id) REFERENCES public."Annotations"(id) ON DELETE CASCADE;


--
-- Name: AnnotationResources AnnotationResources_target_annotation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationResources"
    ADD CONSTRAINT "AnnotationResources_target_annotation_id_fkey" FOREIGN KEY (target_annotation_id) REFERENCES public."Annotations"(id) ON DELETE CASCADE;


--
-- Name: AnnotationSelectors AnnotationSelectors_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AnnotationSelectors"
    ADD CONSTRAINT "AnnotationSelectors_resource_id_fkey" FOREIGN KEY (resource_id) REFERENCES public."AnnotationResources"(_id) ON DELETE CASCADE;


--
-- Name: ExamQuestions ExamQuestions_lang_abbr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamQuestions"
    ADD CONSTRAINT "ExamQuestions_lang_abbr_fkey" FOREIGN KEY (lang_abbr) REFERENCES public."Languages"(abbr) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Exercises Exercises_lang_abbr_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Exercises"
    ADD CONSTRAINT "Exercises_lang_abbr_fkey" FOREIGN KEY (lang_abbr) REFERENCES public."Languages"(abbr) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

